#include "GuiTester.h"

GuiTester::GuiTester(QObject *parent, AutoGUI *win=0)
	: QObject(parent)
{
	this->_win = win;

}

GuiTester::~GuiTester()
{

}

void GuiTester::init()
{
	clearAB();
	testOk = false;
}
void GuiTester::cleanup()
{
	//this->_win->cancel();
	this->_win->ui.tableLog->setCellWidget(0, 3 , new QLabel(testOk? "+":"ERROR")); // test result
}

void GuiTester::clearAB()
{
	this->_win->ui.txeA->clear();
	this->_win->ui.txeB->clear();
}

//int GuiTester::run()
//{
//	summ_ok();
//
//	return 1;
//}

void GuiTester::summ_ok()
{
	//qDebug("running test");
	this->_win->setStatus(tr("running test"), 5000);

	this->_win->ui.cmbMode->setCurrentIndex(0); /// summ mode

	QTest::keyClicks( this->_win->ui.txeA , "1000", Qt::NoModifier, /*delay =*/ 50);
	QTest::keyClicks( this->_win->ui.txeB , "0088", Qt::NoModifier, /*delay =*/ 50);
	QTest::keyClick( this->_win->ui.btnPlus , Qt::Key_Space, Qt::NoModifier, /*delay =*/ 100 );

	QTest::keyClick( this->_win->ui.tabWidget , Qt::Key_Tab, Qt::ControlModifier, /*delay =*/ 500 );
	QTest::keyClick( this->_win->ui.tabWidget , Qt::Key_Tab, Qt::ControlModifier, /*delay =*/ 500 );

	QCOMPARE(this->_win->ui.txtResult->text(), QString("1088"));

	// test passed to the end successfully
	testOk = true;
}
void GuiTester::concat_ok()
{
	//qDebug("running test");
	this->_win->setStatus(tr("running test 2"), 5000);

	this->_win->ui.cmbMode->setCurrentIndex(1); /// concat mode

	QTest::keyClicks( this->_win->ui.txeA , "hello", Qt::NoModifier, /*delay =*/ 50);
	QTest::keyClicks( this->_win->ui.txeB , "WORLD", Qt::NoModifier, /*delay =*/ 50);
	//QTest::mouseClick( this->_win->ui.btnPlus , Qt::LeftButton, Qt::NoModifier, QPoint(), /*delay =*/ 100 );
	QTest::keyClick( this->_win->ui.btnPlus , Qt::Key_Space, Qt::NoModifier, /*delay =*/ 100 );

	QTest::keyClick( this->_win->ui.tabWidget , Qt::Key_Tab, Qt::ControlModifier, /*delay =*/ 500 );
	QTest::keyClick( this->_win->ui.tabWidget , Qt::Key_Tab, Qt::ControlModifier, /*delay =*/ 500 );

	QCOMPARE(this->_win->ui.txtResult->text(), QString("helloWORLD"));
	testOk = true;
}
