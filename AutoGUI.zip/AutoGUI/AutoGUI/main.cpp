#include "autogui.h"
#include "GuiTester.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	AutoGUI w;
	//QTest::
	w.show();

	return a.exec();
}

//QTEST_MAIN(GuiTester)
//#include "autogui.moc"


	//
