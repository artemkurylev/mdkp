/********************************************************************************
** Form generated from reading UI file 'autogui.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AUTOGUI_H
#define UI_AUTOGUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AutoGUIClass
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout_2;
    QTabWidget *tabWidget;
    QWidget *tab;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QComboBox *cmbMode;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout;
    QLineEdit *txeA;
    QPushButton *btnPlus;
    QLineEdit *txeB;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLabel *txtResult;
    QPushButton *btnCancel;
    QWidget *tab_2;
    QHBoxLayout *horizontalLayout_4;
    QTableWidget *tableLog;
    QToolButton *btnRunTest;
    QMenuBar *menuBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *AutoGUIClass)
    {
        if (AutoGUIClass->objectName().isEmpty())
            AutoGUIClass->setObjectName(QStringLiteral("AutoGUIClass"));
        AutoGUIClass->resize(480, 323);
        centralWidget = new QWidget(AutoGUIClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout_2 = new QVBoxLayout(centralWidget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        verticalLayout = new QVBoxLayout(tab);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_2 = new QLabel(tab);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout_2->addWidget(label_2);

        cmbMode = new QComboBox(tab);
        cmbMode->setObjectName(QStringLiteral("cmbMode"));

        horizontalLayout_2->addWidget(cmbMode);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        txeA = new QLineEdit(tab);
        txeA->setObjectName(QStringLiteral("txeA"));

        horizontalLayout->addWidget(txeA);

        btnPlus = new QPushButton(tab);
        btnPlus->setObjectName(QStringLiteral("btnPlus"));

        horizontalLayout->addWidget(btnPlus);

        txeB = new QLineEdit(tab);
        txeB->setObjectName(QStringLiteral("txeB"));

        horizontalLayout->addWidget(txeB);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_3 = new QLabel(tab);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout_3->addWidget(label_3);

        txtResult = new QLabel(tab);
        txtResult->setObjectName(QStringLiteral("txtResult"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(txtResult->sizePolicy().hasHeightForWidth());
        txtResult->setSizePolicy(sizePolicy);
        txtResult->setFrameShape(QFrame::Box);
        txtResult->setFrameShadow(QFrame::Sunken);

        horizontalLayout_3->addWidget(txtResult);


        verticalLayout->addLayout(horizontalLayout_3);

        btnCancel = new QPushButton(tab);
        btnCancel->setObjectName(QStringLiteral("btnCancel"));

        verticalLayout->addWidget(btnCancel);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        horizontalLayout_4 = new QHBoxLayout(tab_2);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        tableLog = new QTableWidget(tab_2);
        if (tableLog->columnCount() < 4)
            tableLog->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableLog->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableLog->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableLog->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableLog->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        tableLog->setObjectName(QStringLiteral("tableLog"));

        horizontalLayout_4->addWidget(tableLog);

        tabWidget->addTab(tab_2, QString());

        verticalLayout_2->addWidget(tabWidget);

        btnRunTest = new QToolButton(centralWidget);
        btnRunTest->setObjectName(QStringLiteral("btnRunTest"));

        verticalLayout_2->addWidget(btnRunTest);

        AutoGUIClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(AutoGUIClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 480, 20));
        AutoGUIClass->setMenuBar(menuBar);
        statusBar = new QStatusBar(AutoGUIClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        AutoGUIClass->setStatusBar(statusBar);

        retranslateUi(AutoGUIClass);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(AutoGUIClass);
    } // setupUi

    void retranslateUi(QMainWindow *AutoGUIClass)
    {
        AutoGUIClass->setWindowTitle(QApplication::translate("AutoGUIClass", "AutoGUI", 0));
        label_2->setText(QApplication::translate("AutoGUIClass", "Mode:", 0));
        cmbMode->clear();
        cmbMode->insertItems(0, QStringList()
         << QApplication::translate("AutoGUIClass", "Summ", 0)
         << QApplication::translate("AutoGUIClass", "Concat", 0)
        );
        btnPlus->setText(QApplication::translate("AutoGUIClass", "+", 0));
        label_3->setText(QApplication::translate("AutoGUIClass", "Result:", 0));
        txtResult->setText(QApplication::translate("AutoGUIClass", "<empty>", 0));
        btnCancel->setText(QApplication::translate("AutoGUIClass", "Cancel", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("AutoGUIClass", "App", 0));
        QTableWidgetItem *___qtablewidgetitem = tableLog->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("AutoGUIClass", "A", 0));
        QTableWidgetItem *___qtablewidgetitem1 = tableLog->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("AutoGUIClass", "B", 0));
        QTableWidgetItem *___qtablewidgetitem2 = tableLog->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("AutoGUIClass", "Result", 0));
        QTableWidgetItem *___qtablewidgetitem3 = tableLog->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("AutoGUIClass", "Test", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("AutoGUIClass", "Log", 0));
        btnRunTest->setText(QApplication::translate("AutoGUIClass", "Run test", 0));
    } // retranslateUi

};

namespace Ui {
    class AutoGUIClass: public Ui_AutoGUIClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AUTOGUI_H
