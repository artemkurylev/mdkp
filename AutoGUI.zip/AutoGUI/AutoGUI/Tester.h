#pragma once
#include <QtTest/QtTest>

class Tester
{
	Q_OBJECT

public:
	Tester(void);
	~Tester(void);
};

