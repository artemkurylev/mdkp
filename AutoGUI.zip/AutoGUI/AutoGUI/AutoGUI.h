#ifndef AUTOGUI_H
#define AUTOGUI_H

#include <QtWidgets/QMainWindow>
#include "ui_autogui.h"


class AutoGUI : public QMainWindow
{
	Q_OBJECT

public:
	AutoGUI(QWidget *parent = 0);
	~AutoGUI();

private:
	Ui::AutoGUIClass ui;

	void setStatus(const QString & message, int timeout = 0);

private slots:
	void perform();
	void cancel();
	void runTest();


friend class GuiTester;

};

#endif // AUTOGUI_H
