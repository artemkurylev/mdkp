#include "autogui.h"
#include "GuiTester.h"


AutoGUI::AutoGUI(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);

	connect(ui.btnPlus,   SIGNAL(clicked()), this, SLOT(perform()));
	connect(ui.btnCancel, SIGNAL(clicked()), this, SLOT(cancel()));
	connect(ui.btnRunTest,SIGNAL(clicked()), this, SLOT(runTest()));
}

AutoGUI::~AutoGUI()
{

}

void AutoGUI::perform()
{
	ui.txtResult->setText("Performed");
	puts("Performed");

	QString a,b,r;
	double af,bf,rf;
	bool a_ok,b_ok;

	a = ui.txeA->text();
	b = ui.txeB->text();

	if(a.isEmpty() || b.isEmpty())
	{
		ui.txtResult->setText("Error: Empty operand(s)");
		return;
	}

	switch(ui.cmbMode->currentIndex())
	{
	case 0:
		af = a.toDouble(&a_ok);
		bf = b.toDouble(&b_ok);
		if(!a_ok || !b_ok)
		{
			r = "Error: Wrong operand(s)";
			break;
		}
		rf = af + bf;
		r = QString::number(rf);

		break;
	case 1:
		r = a + b;
		break;
	default:
		r = "unknown mode";
	}

	ui.txtResult->setText(r);


	// add to TOP of a log
	ui.tableLog->insertRow(0);

	ui.tableLog->setCellWidget(0, 0 , new QLabel(a));
	ui.tableLog->setCellWidget(0, 1 , new QLabel(b));
	ui.tableLog->setCellWidget(0, 2 , new QLabel(r));
	ui.tableLog->setCellWidget(0, 3 , new QLabel("?")); // test result
}


void AutoGUI::cancel()
{
	ui.txtResult->clear();
	ui.txeA->clear();
	ui.txeB->clear();

}

void AutoGUI::runTest()
{
	GuiTester tester(0, this);

	bool success = false;

	success = ! QTest::qExec( & tester/*, args*/ );

	setStatus(success ? (" >> + All tests are OK") : (" >> - Some tests are NOT OK") );

}


void AutoGUI::setStatus(const QString & message, int timeout)
{
	ui.statusBar->showMessage(message, timeout);
}