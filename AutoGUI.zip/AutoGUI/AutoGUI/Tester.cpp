#include "Tester.h"


Tester::Tester(void)
{
}


Tester::~Tester(void)
{
}
