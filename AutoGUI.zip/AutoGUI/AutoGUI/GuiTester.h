#ifndef GUITESTER_H
#define GUITESTER_H

#include <QObject>
#include <QtTest/QtTest>
#include "autogui.h"
#include <QtWidgets/QApplication>


class GuiTester : public QObject
{
	Q_OBJECT

public:
	GuiTester(QObject *parent, AutoGUI *win);
	~GuiTester();
	//int run();

private:
	AutoGUI *_win;
	bool testOk;
	void clearAB();

private slots:
	//void initTestCase();
	//void cleanupTestCase();

	void init();
	void cleanup();

    void summ_ok();
    void concat_ok();

};

#endif // GUITESTER_H
