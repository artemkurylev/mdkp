/********************************************************************************
** Form generated from reading UI file 'mysqlprototype.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYSQLPROTOTYPE_H
#define UI_MYSQLPROTOTYPE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MYSQLPROTOTYPEClass
{
public:
    QWidget *centralWidget;
    QPushButton *createButton;
    QLineEdit *FioEdit;
    QLabel *label;
    QLabel *label_2;
    QSpinBox *INNNum;
    QLineEdit *adressEdit;
    QLabel *label_3;
    QSpinBox *phoneEdit;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *positionEdit;
    QTableWidget *users;
    QPushButton *deleteButton;
    QPushButton *updateButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MYSQLPROTOTYPEClass)
    {
        if (MYSQLPROTOTYPEClass->objectName().isEmpty())
            MYSQLPROTOTYPEClass->setObjectName(QStringLiteral("MYSQLPROTOTYPEClass"));
        MYSQLPROTOTYPEClass->resize(600, 400);
        centralWidget = new QWidget(MYSQLPROTOTYPEClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        createButton = new QPushButton(centralWidget);
        createButton->setObjectName(QStringLiteral("createButton"));
        createButton->setGeometry(QRect(410, 270, 91, 23));
        FioEdit = new QLineEdit(centralWidget);
        FioEdit->setObjectName(QStringLiteral("FioEdit"));
        FioEdit->setGeometry(QRect(400, 30, 113, 20));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(400, 10, 81, 16));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(400, 60, 47, 13));
        INNNum = new QSpinBox(centralWidget);
        INNNum->setObjectName(QStringLiteral("INNNum"));
        INNNum->setGeometry(QRect(400, 80, 111, 22));
        INNNum->setMinimum(1);
        INNNum->setMaximum(999999999);
        adressEdit = new QLineEdit(centralWidget);
        adressEdit->setObjectName(QStringLiteral("adressEdit"));
        adressEdit->setGeometry(QRect(400, 130, 113, 20));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(400, 110, 47, 13));
        phoneEdit = new QSpinBox(centralWidget);
        phoneEdit->setObjectName(QStringLiteral("phoneEdit"));
        phoneEdit->setGeometry(QRect(400, 180, 111, 22));
        phoneEdit->setMinimum(100000000);
        phoneEdit->setMaximum(999999999);
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(400, 160, 47, 13));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(400, 210, 111, 16));
        positionEdit = new QLineEdit(centralWidget);
        positionEdit->setObjectName(QStringLiteral("positionEdit"));
        positionEdit->setGeometry(QRect(400, 230, 113, 20));
        users = new QTableWidget(centralWidget);
        if (users->columnCount() < 6)
            users->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        users->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        users->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        users->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        users->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        users->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        users->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        users->setObjectName(QStringLiteral("users"));
        users->setGeometry(QRect(10, 0, 381, 281));
        deleteButton = new QPushButton(centralWidget);
        deleteButton->setObjectName(QStringLiteral("deleteButton"));
        deleteButton->setGeometry(QRect(10, 300, 101, 23));
        updateButton = new QPushButton(centralWidget);
        updateButton->setObjectName(QStringLiteral("updateButton"));
        updateButton->setGeometry(QRect(130, 300, 121, 23));
        MYSQLPROTOTYPEClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MYSQLPROTOTYPEClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 600, 21));
        MYSQLPROTOTYPEClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MYSQLPROTOTYPEClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MYSQLPROTOTYPEClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MYSQLPROTOTYPEClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MYSQLPROTOTYPEClass->setStatusBar(statusBar);

        retranslateUi(MYSQLPROTOTYPEClass);

        QMetaObject::connectSlotsByName(MYSQLPROTOTYPEClass);
    } // setupUi

    void retranslateUi(QMainWindow *MYSQLPROTOTYPEClass)
    {
        MYSQLPROTOTYPEClass->setWindowTitle(QApplication::translate("MYSQLPROTOTYPEClass", "MYSQLPROTOTYPE", 0));
        createButton->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\241\320\276\320\267\320\264\320\260\321\202\321\214 \320\267\320\260\320\277\320\270\321\201\321\214", 0));
        label->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\244\320\230\320\236", 0));
        label_2->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\230\320\235\320\235", 0));
        label_3->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\220\320\264\321\200\320\265\321\201", 0));
        label_4->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\242\320\265\320\273\320\265\321\204\320\276\320\275", 0));
        label_5->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\224\320\276\320\273\320\266\320\275\320\276\321\201\321\202\321\214", 0));
        QTableWidgetItem *___qtablewidgetitem = users->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("MYSQLPROTOTYPEClass", "id", 0));
        QTableWidgetItem *___qtablewidgetitem1 = users->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\244\320\230\320\236", 0));
        QTableWidgetItem *___qtablewidgetitem2 = users->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\230\320\235\320\235", 0));
        QTableWidgetItem *___qtablewidgetitem3 = users->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\220\320\264\321\200\320\265\321\201", 0));
        QTableWidgetItem *___qtablewidgetitem4 = users->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\242\320\265\320\273\320\265\321\204\320\276\320\275", 0));
        QTableWidgetItem *___qtablewidgetitem5 = users->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\224\320\276\320\273\320\266\320\275\320\276\321\201\321\202\321\214", 0));
        deleteButton->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214 \320\267\320\260\320\277\320\270\321\201\321\214", 0));
        updateButton->setText(QApplication::translate("MYSQLPROTOTYPEClass", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214 \320\267\320\260\320\277\320\270\321\201\321\214", 0));
    } // retranslateUi

};

namespace Ui {
    class MYSQLPROTOTYPEClass: public Ui_MYSQLPROTOTYPEClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYSQLPROTOTYPE_H
