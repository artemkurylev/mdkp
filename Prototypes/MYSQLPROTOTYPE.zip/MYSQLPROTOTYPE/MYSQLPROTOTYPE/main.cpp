#include "mysqlprototype.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MYSQLPROTOTYPE w;
    w.show();
    return a.exec();
}
