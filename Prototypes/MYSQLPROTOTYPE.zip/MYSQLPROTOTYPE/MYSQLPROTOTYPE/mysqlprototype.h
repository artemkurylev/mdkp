#ifndef MYSQLPROTOTYPE_H
#define MYSQLPROTOTYPE_H

#include <QtWidgets/QMainWindow>
#include "ui_mysqlprototype.h"
#include<qsqldatabase.h>

class MYSQLPROTOTYPE : public QMainWindow
{
    Q_OBJECT

public:
    MYSQLPROTOTYPE(QWidget *parent = 0);
    ~MYSQLPROTOTYPE();

private:
    Ui::MYSQLPROTOTYPEClass ui;
    QSqlDatabase db;
    void showDB();
private slots:
    void create();
    void update();
    void delet();
};

#endif // MYSQLPROTOTYPE_H
