#include "mysqlprototype.h"
#include <qsql.h>
#include <qsqldatabase.h>
#include<qsqlquery.h>
#include<qtablewidget.h>
#include<qdebug.h>
#include<qsqlerror.h>
MYSQLPROTOTYPE::MYSQLPROTOTYPE(QWidget *parent)
    : QMainWindow(parent)
{

    ui.setupUi(this);
    db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("127.0.0.1");
    db.setPort(3306);
    db.setUserName("root");
    db.setPassword("root");
    db.setDatabaseName("mydb");
    if(db.open()){
        QSqlQuery* query = new QSqlQuery(db);
        query->exec("SELECT FIO, INN, adress, phone_number, position from users");
        ui.users->setColumnWidth(0,0);
    
        int insertPos = 0;
        while(query->next()){
            ui.users->insertRow(insertPos);
            QTableWidgetItem *item;

            item = new QTableWidgetItem(query->value(0).toString());
            ui.users->setItem(insertPos, 1, item);
        
            item = new QTableWidgetItem(query->value(1).toString());
            int c = query->value(1).toInt();
            ui.users->setItem(insertPos,2,item);

            item = new QTableWidgetItem(query->value(2).toString());
            ui.users->setItem(insertPos, 3, item);

            item = new QTableWidgetItem(query->value(3).toString());
            ui.users->setItem(insertPos, 4, item);
            

            item = new QTableWidgetItem(query->value(4).toString());
            ui.users->setItem(insertPos, 5, item);

            insertPos++;
        }
    }

    connect(ui.createButton,SIGNAL(clicked()),this,SLOT(create()));
    connect(ui.deleteButton,SIGNAL(clicked()),this,SLOT(delet()));
    connect(ui.updateButton,SIGNAL(clicked()),this,SLOT(update()));
}

MYSQLPROTOTYPE::~MYSQLPROTOTYPE()
{

}

void MYSQLPROTOTYPE::create(){
    int INN = ui.INNNum->value();
    QString FIO = ui.FioEdit->text();
    QString position = ui.positionEdit->text();
    QString adress = ui.adressEdit->text();
    int phone = ui.phoneEdit->value();
    if(db.open()){
        QSqlQuery query(db);
        query.prepare("INSERT INTO users (FIO,INN,adress,phone_number,position) VALUES(:FIO, :INN, :adress, :phone_number, :position)");
        query.bindValue(":FIO",FIO);
        query.bindValue(":INN",INN);
        query.bindValue(":position",position);
        query.bindValue(":adress",adress);
        query.bindValue(":phone_number",phone);
        query.exec();
    }
    db.close();
    showDB();
}
void MYSQLPROTOTYPE::update(){
    int row = ui.users->currentRow();
    QString FIO = ui.users->item(row, 1)->text();

    int INN = ui.users->item(row,2)->text().toInt();
    QString adress = ui.users->item(row,3)->text();
    int phone = ui.users->item(row,4)->text().toInt();
    QString position = ui.users->item(row,5)->text(); 
    if(db.open()){
        QSqlQuery query(db);
        query.prepare("UPDATE users SET FIO=:FIO,adress =:adress,phone_number=:phone_number,position=:position WHERE INN=:INN");
        query.bindValue(":FIO",FIO);
        query.bindValue(":INN",INN);
        query.bindValue(":position",position);
        query.bindValue(":adress",adress);
        query.bindValue(":phone_number",phone);
        query.exec();
        showDB();
    }
}
void MYSQLPROTOTYPE::delet(){
    int row = ui.users->currentRow();
    int INN = ui.users->item(row,2)->text().toInt();
    if(db.open()){
        QSqlQuery query(db);
        query.prepare("DELETE from users WHERE INN = :INN");
        query.bindValue(":INN",INN);
        query.exec();
        showDB();
    }
}
void MYSQLPROTOTYPE::showDB(){
    ui.users->clear();
    while(ui.users->rowCount())
        ui.users->removeRow(0);
    if(db.open()){
        QSqlQuery* query = new QSqlQuery(db);
        query->exec("SELECT FIO, INN, adress, phone_number, position from users");
        ui.users->setColumnWidth(0,0);
    
        int insertPos = 0;
        while(query->next()){
            ui.users->insertRow(insertPos);
            QTableWidgetItem *item;

            item = new QTableWidgetItem(query->value(0).toString());
            ui.users->setItem(insertPos, 1, item);
        
            item = new QTableWidgetItem(query->value(1).toString());
            int c = query->value(1).toInt();
            ui.users->setItem(insertPos,2,item);

            item = new QTableWidgetItem(query->value(2).toString());
            ui.users->setItem(insertPos, 3, item);

            item = new QTableWidgetItem(query->value(3).toString());
            ui.users->setItem(insertPos, 4, item);
            

            item = new QTableWidgetItem(query->value(4).toString());
            ui.users->setItem(insertPos, 5, item);
            insertPos++;
        }
    }
}

