function func() {

    return 5;
}
